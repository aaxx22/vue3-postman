﻿# vue3-postman
## 运行

``` bash
$ git clone https://github.com/muhan-666/vue3-postman.git

$ cd vue3-postman

# install
$ npm install

# serve with hot reload at localhost:3000
$ npm run dev

# build for production and launch server
$ npm run build

```
